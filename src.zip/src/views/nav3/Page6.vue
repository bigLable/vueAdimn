<template>
	<section>page6...
	</section>
</template>